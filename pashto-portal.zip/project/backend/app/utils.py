import re
import uuid
from html import escape

import bleach
from sqlalchemy.orm import Session

from .models import Article, Category, Notification, SiteSetting

ALLOWED_TAGS = ["p", "br", "h2", "h3", "h4", "strong", "b", "em", "i", "u", "s", "ul", "ol", "li",
                "blockquote", "a", "img", "span"]


def _attr(tag, name, value):
    if name == "class":  # only Quill formatting classes (alignment, direction)
        return all(c.startswith("ql-") for c in value.split())
    if tag == "a":
        return name in ("href", "title", "target", "rel")
    if tag == "img":
        return name in ("src", "alt")
    return False


def clean_html(html: str) -> str:
    return bleach.clean(html or "", tags=ALLOWED_TAGS, attributes=_attr,
                        protocols=["http", "https", "mailto"], strip=True)


def text_to_html(text: str) -> str:
    paras = [p.strip() for p in re.split(r"\n{2,}", (text or "").replace("\r", "")) if p.strip()]
    return "".join(f"<p>{escape(p).replace(chr(10), '<br>')}</p>" for p in paras)


def slugify(text: str) -> str:
    """Unicode-aware slug (keeps Pashto/Arabic letters)."""
    s = re.sub(r"[^\w\s-]", "", (text or "").strip().lower(), flags=re.UNICODE)
    s = re.sub(r"[\s_-]+", "-", s).strip("-")
    return s[:80] or "item"


def unique_slug(db: Session, model, title: str, exclude_id: int | None = None) -> str:
    base = slugify(title)
    slug = base
    while True:
        q = db.query(model).filter(model.slug == slug)
        if exclude_id:
            q = q.filter(model.id != exclude_id)
        if not q.first():
            return slug
        slug = f"{base}-{uuid.uuid4().hex[:5]}"


def notify(db: Session, user_id: int, message: str, article_id: int | None = None):
    db.add(Notification(user_id=user_id, article_id=article_id, message=message))


def article_url(a: Article) -> str:
    cat = a.category.slug if a.category else "general"
    return f"/articles/{cat}/{a.slug}"


def card(a: Article) -> dict:
    return {
        "id": a.id, "title": a.title, "slug": a.slug, "url": article_url(a),
        "short_description": a.short_description,
        "image": a.featured_image, "thumb": a.featured_thumb or a.featured_image,
        "category": {"name": a.category.name, "slug": a.category.slug} if a.category else None,
        "author": a.author.name if a.author else "",
        "views": a.views, "approved_at": a.approved_at,
    }


def get_settings_dict(db: Session) -> dict:
    return {s.key: s.value or "" for s in db.query(SiteSetting).all()}


SETTING_KEYS = ["site_name", "site_tagline", "site_logo", "about", "contact_email", "contact_phone",
                "contact_address", "social_facebook", "social_x", "social_youtube", "social_telegram",
                "social_whatsapp"]
