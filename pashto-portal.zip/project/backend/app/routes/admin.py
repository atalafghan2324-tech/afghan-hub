"""ADMIN API – every route here requires an authenticated user whose role in the DB is 'admin'."""
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile
from sqlalchemy import func, or_
from sqlalchemy.orm import Session, joinedload

from ..database import get_db
from ..deps import require_admin
from ..models import Article, ArticleImage, Category, SiteSetting, User
from ..schemas import (AdminArticleUpdate, AdminUserUpdate, CategoryIn, RejectIn,
                       SettingsIn, user_out)
from ..services.images import save_image
from ..utils import (SETTING_KEYS, article_url, card, clean_html, get_settings_dict,
                     notify, slugify, unique_slug)

router = APIRouter(prefix="/api/admin", tags=["admin"], dependencies=[Depends(require_admin)])


def _esc(q: str) -> str:
    return "%" + q.strip().replace("\\", "\\\\").replace("%", r"\%").replace("_", r"\_") + "%"


def _get(db: Session, article_id: int) -> Article:
    a = db.get(Article, article_id)
    if not a:
        raise HTTPException(404, "Article not found")
    return a


def _full(a: Article) -> dict:
    d = card(a)
    d.update(status=a.status, rejection_reason=a.rejection_reason, created_at=a.created_at,
             content=a.content, location=a.location, social_link=a.social_link,
             is_featured=a.is_featured, category_id=a.category_id,
             contact_name=a.contact_name, contact_email=a.contact_email, contact_phone=a.contact_phone,
             author_email=a.author.email if a.author else None,
             images=[{"id": i.id, "url": i.image_url, "thumb": i.thumb_url} for i in a.images])
    return d


# ------------------------------------------------------------------ stats
@router.get("/stats")
def stats(db: Session = Depends(get_db)):
    by_status = dict(db.query(Article.status, func.count(Article.id)).group_by(Article.status).all())
    return {"users": db.query(func.count(User.id)).scalar(),
            "articles": sum(by_status.values()),
            "pending": by_status.get("pending", 0), "approved": by_status.get("approved", 0),
            "rejected": by_status.get("rejected", 0),
            "categories": db.query(func.count(Category.id)).scalar()}


# --------------------------------------------------------------- articles
@router.get("/articles")
def list_articles(db: Session = Depends(get_db), page: int = Query(1, ge=1), size: int = Query(20, ge=1, le=50),
                  status: str | None = Query(None, pattern="^(pending|approved|rejected)$"),
                  q: str | None = Query(None, max_length=100)):
    query = db.query(Article).options(joinedload(Article.author), joinedload(Article.category), joinedload(Article.images))
    if status:
        query = query.filter(Article.status == status)
    if q and q.strip():
        query = query.filter(Article.title.ilike(_esc(q)))
    total = query.count()
    rows = query.order_by(Article.created_at.desc()).offset((page - 1) * size).limit(size).all()
    return {"items": [_full(a) for a in rows], "total": total, "page": page, "pages": max(1, -(-total // size))}


@router.post("/articles", status_code=201)
def create_article(title: str = Form(..., min_length=3, max_length=250), category_id: int | None = Form(None),
                   short_description: str = Form(..., min_length=10, max_length=600),
                   content: str = Form(..., min_length=10), location: str | None = Form(None),
                   social_link: str | None = Form(None), is_featured: bool = Form(False),
                   main_image: UploadFile | None = File(None),
                   admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    if category_id and not db.get(Category, category_id):
        raise HTTPException(422, "Invalid category")
    img = thumb = None
    if main_image and main_image.filename:
        img, thumb = save_image(main_image)
    a = Article(author_id=admin.id, category_id=category_id, title=title.strip(),
                slug=unique_slug(db, Article, title), short_description=short_description.strip(),
                content=clean_html(content), featured_image=img, featured_thumb=thumb,
                location=location or None, social_link=social_link or None, is_featured=is_featured,
                status="approved", approved_at=datetime.now(timezone.utc),
                contact_name=admin.name, contact_email=admin.email)
    db.add(a)
    db.commit()
    return _full(a)


@router.get("/articles/{article_id}")
def get_article(article_id: int, db: Session = Depends(get_db)):
    return _full(_get(db, article_id))


@router.put("/articles/{article_id}")
def update_article(article_id: int, data: AdminArticleUpdate, db: Session = Depends(get_db)):
    a = _get(db, article_id)
    if data.category_id and not db.get(Category, data.category_id):
        raise HTTPException(422, "Invalid category")
    a.title, a.category_id, a.short_description = data.title.strip(), data.category_id, data.short_description.strip()
    a.content = clean_html(data.content)  # always sanitise rich text before storing
    a.location, a.social_link, a.is_featured = data.location or None, data.social_link or None, data.is_featured
    db.commit()
    return _full(a)


@router.post("/articles/{article_id}/approve")
def approve(article_id: int, db: Session = Depends(get_db)):
    a = _get(db, article_id)
    a.status, a.rejection_reason, a.approved_at = "approved", None, datetime.now(timezone.utc)
    notify(db, a.author_id, f"Your article «{a.title}» was approved and is now published.", a.id)
    db.commit()
    return _full(a)


@router.post("/articles/{article_id}/reject")
def reject(article_id: int, data: RejectIn, db: Session = Depends(get_db)):
    a = _get(db, article_id)
    a.status, a.rejection_reason, a.approved_at, a.is_featured = "rejected", data.reason.strip(), None, False
    notify(db, a.author_id, f"Your article «{a.title}» was rejected. Reason: {a.rejection_reason}", a.id)
    db.commit()
    return _full(a)


@router.delete("/articles/{article_id}")
def delete_article(article_id: int, db: Session = Depends(get_db)):
    db.delete(_get(db, article_id))
    db.commit()
    return {"ok": True}


@router.post("/articles/{article_id}/images", status_code=201)
def add_image(article_id: int, file: UploadFile = File(...), db: Session = Depends(get_db)):
    a = _get(db, article_id)
    u, t = save_image(file)
    db.add(ArticleImage(article_id=a.id, image_url=u, thumb_url=t, sort_order=len(a.images)))
    db.commit()
    return {"ok": True}


@router.delete("/articles/{article_id}/images/{image_id}")
def delete_image(article_id: int, image_id: int, db: Session = Depends(get_db)):
    img = db.query(ArticleImage).filter(ArticleImage.id == image_id, ArticleImage.article_id == article_id).first()
    if not img:
        raise HTTPException(404, "Image not found")
    db.delete(img)
    db.commit()
    return {"ok": True}


@router.post("/articles/{article_id}/main-image")
def replace_main_image(article_id: int, file: UploadFile = File(...), db: Session = Depends(get_db)):
    a = _get(db, article_id)
    a.featured_image, a.featured_thumb = save_image(file)
    db.commit()
    return {"ok": True}


@router.post("/upload-image")
def editor_image(file: UploadFile = File(...)):
    """Used by the rich-text editor to insert images inside article content."""
    url, _ = save_image(file, folder="content", thumb=False)
    return {"url": url}


# ------------------------------------------------------------------ users
@router.get("/users")
def list_users(db: Session = Depends(get_db), page: int = Query(1, ge=1), size: int = Query(20, ge=1, le=50),
               q: str | None = Query(None, max_length=100)):
    query = db.query(User)
    if q and q.strip():
        query = query.filter(or_(User.name.ilike(_esc(q)), User.email.ilike(_esc(q))))
    total = query.count()
    rows = query.order_by(User.created_at.desc()).offset((page - 1) * size).limit(size).all()
    return {"items": [user_out(u) for u in rows], "total": total, "page": page, "pages": max(1, -(-total // size))}


@router.patch("/users/{user_id}")
def update_user(user_id: int, data: AdminUserUpdate, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    u = db.get(User, user_id)
    if not u:
        raise HTTPException(404, "User not found")
    if u.id == admin.id and (data.role == "user" or data.is_active is False):
        raise HTTPException(400, "You cannot demote or disable your own account")
    if data.name is not None:
        u.name = data.name.strip()
    if data.role is not None:
        u.role = data.role
    if data.is_active is not None:
        u.is_active = data.is_active
    db.commit()
    return user_out(u)


@router.delete("/users/{user_id}")
def delete_user(user_id: int, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    u = db.get(User, user_id)
    if not u:
        raise HTTPException(404, "User not found")
    if u.id == admin.id:
        raise HTTPException(400, "You cannot delete your own account")
    db.delete(u)  # also deletes the user's articles, notifications and sessions
    db.commit()
    return {"ok": True}


# ------------------------------------------------------------- categories
@router.post("/categories", status_code=201)
def create_category(data: CategoryIn, db: Session = Depends(get_db)):
    if db.query(Category).filter(Category.name == data.name.strip()).first():
        raise HTTPException(409, "A category with this name already exists")
    c = Category(name=data.name.strip(), description=data.description,
                 slug=unique_slug(db, Category, data.slug or data.name))
    db.add(c)
    db.commit()
    return {"id": c.id, "name": c.name, "slug": c.slug, "description": c.description}


@router.put("/categories/{category_id}")
def update_category(category_id: int, data: CategoryIn, db: Session = Depends(get_db)):
    c = db.get(Category, category_id)
    if not c:
        raise HTTPException(404, "Category not found")
    clash = db.query(Category).filter(Category.name == data.name.strip(), Category.id != c.id).first()
    if clash:
        raise HTTPException(409, "A category with this name already exists")
    c.name, c.description = data.name.strip(), data.description
    if data.slug:
        c.slug = unique_slug(db, Category, data.slug, exclude_id=c.id)
    db.commit()
    return {"id": c.id, "name": c.name, "slug": c.slug, "description": c.description}


@router.delete("/categories/{category_id}")
def delete_category(category_id: int, db: Session = Depends(get_db)):
    c = db.get(Category, category_id)
    if not c:
        raise HTTPException(404, "Category not found")
    db.delete(c)  # articles keep existing; their category becomes empty
    db.commit()
    return {"ok": True}


# --------------------------------------------------------------- settings
@router.get("/settings")
def get_settings(db: Session = Depends(get_db)):
    return get_settings_dict(db)


@router.put("/settings")
def put_settings(data: SettingsIn, db: Session = Depends(get_db)):
    for key, value in data.values.items():
        if key not in SETTING_KEYS or key == "site_logo":
            continue
        if key.startswith("social_") and value and not value.startswith(("http://", "https://")):
            raise HTTPException(422, f"{key} must be a full URL (https://...)")
        row = db.get(SiteSetting, key) or SiteSetting(key=key)
        row.value = value[:5000]
        db.add(row)
    db.commit()
    return get_settings_dict(db)


@router.post("/settings/logo")
def upload_logo(file: UploadFile = File(...), db: Session = Depends(get_db)):
    url, _ = save_image(file, folder="site", thumb=False)
    row = db.get(SiteSetting, "site_logo") or SiteSetting(key="site_logo")
    row.value = url
    db.add(row)
    db.commit()
    return {"url": url}
