"""Server-rendered pages for SEO: article page (meta tags / Open Graph), sitemap and robots."""
from datetime import datetime
from pathlib import Path
from urllib.parse import quote

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import RedirectResponse, Response
from fastapi.templating import Jinja2Templates
from sqlalchemy import update
from sqlalchemy.orm import Session

from ..config import settings
from ..database import get_db
from ..models import Article
from ..utils import article_url, get_settings_dict
from .public import approved_query

router = APIRouter(include_in_schema=False)
templates = Jinja2Templates(directory=str(Path(__file__).resolve().parents[1] / "templates"))


def absolute(url: str | None) -> str:
    if not url:
        return ""
    return url if url.startswith("http") else settings.SITE_URL.rstrip("/") + url


@router.get("/articles/{category_slug}/{slug}")
def article_page(request: Request, category_slug: str, slug: str, db: Session = Depends(get_db)):
    a = approved_query(db).filter(Article.slug == slug).first()  # approved only
    if not a:
        raise HTTPException(404, "Article not found")
    canonical = article_url(a)
    if request.url.path != quote(canonical, safe="/%") and request.url.path != canonical:
        return RedirectResponse(quote(canonical, safe="/"), status_code=301)
    db.execute(update(Article).where(Article.id == a.id).values(views=Article.views + 1))
    db.commit()
    related = (approved_query(db).filter(Article.category_id == a.category_id, Article.id != a.id)
               .order_by(Article.approved_at.desc()).limit(3).all()) if a.category_id else []
    site = get_settings_dict(db)
    return templates.TemplateResponse(request, "article.html", {
        "a": a, "site": site, "related": related, "article_url": article_url,
        "canonical": absolute(quote(canonical, safe="/")), "og_image": absolute(a.featured_image),
        "share_url": quote(absolute(quote(canonical, safe="/")), safe=""),
        "share_title": quote(a.title, safe=""),
    })


@router.get("/robots.txt")
def robots():
    body = f"User-agent: *\nDisallow: /api/\nDisallow: /admin.html\nDisallow: /dashboard.html\nSitemap: {settings.SITE_URL.rstrip('/')}/sitemap.xml\n"
    return Response(body, media_type="text/plain")


@router.get("/sitemap.xml")
def sitemap(db: Session = Depends(get_db)):
    base = settings.SITE_URL.rstrip("/")
    urls = [f"<url><loc>{base}/</loc></url>", f"<url><loc>{base}/articles.html</loc></url>"]
    for a in approved_query(db).order_by(Article.approved_at.desc()).limit(5000):
        lastmod = (a.updated_at or a.approved_at or datetime.utcnow()).date().isoformat()
        urls.append(f"<url><loc>{base}{quote(article_url(a), safe='/')}</loc><lastmod>{lastmod}</lastmod></url>")
    xml = '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' + "".join(urls) + "</urlset>"
    return Response(xml, media_type="application/xml")
