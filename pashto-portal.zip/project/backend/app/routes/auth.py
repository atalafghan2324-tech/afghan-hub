from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from sqlalchemy.orm import Session

from ..config import settings
from ..database import get_db
from ..limiter import limiter
from ..models import RefreshToken, User
from ..schemas import LoginIn, RegisterIn, user_out
from ..security import (create_access_token, hash_password, hash_token,
                        new_refresh_token, verify_password)

router = APIRouter(prefix="/api/auth", tags=["auth"])
COOKIE = "refresh_token"


def _issue(db: Session, user: User, response: Response) -> dict:
    raw, hashed = new_refresh_token()
    exp = datetime.now(timezone.utc) + timedelta(days=settings.REFRESH_TOKEN_DAYS)
    db.add(RefreshToken(user_id=user.id, token_hash=hashed, expires_at=exp))
    db.commit()
    response.set_cookie(COOKIE, raw, max_age=settings.REFRESH_TOKEN_DAYS * 86400, httponly=True,
                        secure=settings.COOKIE_SECURE, samesite="lax", path="/api/auth")
    return {"access_token": create_access_token(user.id), "user": user_out(user)}


@router.post("/register", status_code=201)
@limiter.limit("10/hour")
def register(request: Request, data: RegisterIn, response: Response, db: Session = Depends(get_db)):
    email = data.email.lower()
    if db.query(User).filter(User.email == email).first():
        raise HTTPException(409, "This email is already registered")
    # Role is ALWAYS "user" here. Admins can only be created by the bootstrap script or by another admin.
    user = User(name=data.name, email=email, phone=data.phone, password_hash=hash_password(data.password), role="user")
    db.add(user)
    db.commit()
    return _issue(db, user, response)


@router.post("/login")
@limiter.limit("10/minute")
def login(request: Request, data: LoginIn, response: Response, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == data.email.lower()).first()
    if not user or not verify_password(data.password, user.password_hash):
        raise HTTPException(401, "Incorrect email or password")
    if not user.is_active:
        raise HTTPException(403, "This account has been disabled")
    return _issue(db, user, response)


@router.post("/refresh")
def refresh(request: Request, response: Response, db: Session = Depends(get_db)):
    raw = request.cookies.get(COOKIE)
    if not raw:
        raise HTTPException(401, "No session")
    tok = db.query(RefreshToken).filter(RefreshToken.token_hash == hash_token(raw)).first()
    if not tok or tok.revoked or tok.expires_at < datetime.now(timezone.utc):
        response.delete_cookie(COOKIE, path="/api/auth")
        raise HTTPException(401, "Session expired")
    user = db.get(User, tok.user_id)
    if not user or not user.is_active:
        raise HTTPException(401, "Session expired")
    tok.revoked = True  # rotation: every refresh token is single-use
    return _issue(db, user, response)


@router.post("/logout")
def logout(request: Request, response: Response, db: Session = Depends(get_db)):
    raw = request.cookies.get(COOKIE)
    if raw:
        tok = db.query(RefreshToken).filter(RefreshToken.token_hash == hash_token(raw)).first()
        if tok:
            tok.revoked = True
            db.commit()
    response.delete_cookie(COOKIE, path="/api/auth")
    return {"ok": True}
