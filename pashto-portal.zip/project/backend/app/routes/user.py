from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, Request, UploadFile
from sqlalchemy.orm import Session, joinedload

from ..database import get_db
from ..deps import get_current_user
from ..limiter import limiter
from ..models import Article, ArticleImage, Category, Notification, User
from ..schemas import PasswordChange, ProfileUpdate, user_out
from ..security import hash_password, verify_password
from ..services.images import save_image
from ..utils import clean_html, card, notify, text_to_html, unique_slug

router = APIRouter(prefix="/api/me", tags=["user"])
MAX_EXTRA_IMAGES = 8


@router.get("")
def me(user: User = Depends(get_current_user)):
    return user_out(user)


@router.patch("")
def update_me(data: ProfileUpdate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    user.name, user.phone, user.bio = data.name.strip(), data.phone, data.bio
    db.commit()
    return user_out(user)


@router.post("/avatar")
def avatar(file: UploadFile = File(...), user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    user.profile_image, _ = save_image(file, folder="avatars", thumb=False)
    db.commit()
    return user_out(user)


@router.post("/password")
def change_password(data: PasswordChange, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if not verify_password(data.current_password, user.password_hash):
        raise HTTPException(400, "Current password is incorrect")
    user.password_hash = hash_password(data.new_password)
    db.commit()
    return {"ok": True}


# ---------------------------------------------------------------- submissions
def _mine(a: Article) -> dict:
    d = card(a)
    d.update(status=a.status, rejection_reason=a.rejection_reason, created_at=a.created_at,
             short_description=a.short_description, location=a.location, social_link=a.social_link,
             contact_name=a.contact_name, contact_email=a.contact_email, contact_phone=a.contact_phone,
             category_id=a.category_id)
    return d


def _own(db: Session, user: User, article_id: int) -> Article:
    # Ownership is part of the query: another user's article simply "does not exist" for you.
    a = db.query(Article).filter(Article.id == article_id, Article.author_id == user.id).first()
    if not a:
        raise HTTPException(404, "Submission not found")
    return a


def _check_fields(db, title, category_id, short_description, content):
    if not (3 <= len(title.strip()) <= 250):
        raise HTTPException(422, "Title must be between 3 and 250 characters")
    if not (10 <= len(short_description.strip()) <= 600):
        raise HTTPException(422, "Short description must be between 10 and 600 characters")
    if len(content.strip()) < 30:
        raise HTTPException(422, "Content is too short")
    if len(content) > 100_000:
        raise HTTPException(422, "Content is too long")
    if not db.get(Category, category_id):
        raise HTTPException(422, "Invalid category")


def _link(v: str | None) -> str | None:
    v = (v or "").strip()
    if v and not v.lower().startswith(("http://", "https://")):
        raise HTTPException(422, "Social media link must start with http:// or https://")
    return v or None


@router.get("/articles")
def my_articles(status: str | None = Query(None, pattern="^(pending|approved|rejected)$"),
                user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    q = (db.query(Article).options(joinedload(Article.author), joinedload(Article.category))
         .filter(Article.author_id == user.id))
    if status:
        q = q.filter(Article.status == status)
    return [_mine(a) for a in q.order_by(Article.created_at.desc()).all()]


@router.get("/articles/{article_id}")
def my_article(article_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    a = _own(db, user, article_id)
    d = _mine(a)
    d["content_text"] = a.content
    return d


@router.post("/articles", status_code=201)
@limiter.limit("20/hour")
def submit_article(request: Request,
                   full_name: str = Form(..., max_length=120), email: str = Form(..., max_length=255),
                   phone: str = Form(..., max_length=40), title: str = Form(...),
                   category_id: int = Form(...), short_description: str = Form(...),
                   content: str = Form(...), location: str | None = Form(None, max_length=200),
                   social_link: str | None = Form(None, max_length=500),
                   main_image: UploadFile = File(...), extra_images: list[UploadFile] = File(default=[]),
                   user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    _check_fields(db, title, category_id, short_description, content)
    extra_images = [f for f in extra_images if f and f.filename]
    if len(extra_images) > MAX_EXTRA_IMAGES:
        raise HTTPException(422, f"You can upload at most {MAX_EXTRA_IMAGES} additional images")
    img, thumb = save_image(main_image)
    article = Article(
        author_id=user.id, category_id=category_id, title=title.strip(),
        slug=unique_slug(db, Article, title), short_description=short_description.strip(),
        content=text_to_html(content), featured_image=img, featured_thumb=thumb,
        status="pending",  # <- forced by the server; the client cannot choose a status
        location=(location or "").strip() or None, social_link=_link(social_link),
        contact_name=full_name.strip(), contact_email=email.strip(), contact_phone=phone.strip())
    db.add(article)
    db.flush()
    for i, f in enumerate(extra_images):
        u, t = save_image(f)
        db.add(ArticleImage(article_id=article.id, image_url=u, thumb_url=t, sort_order=i))
    notify(db, user.id, f"Your submission «{article.title}» was sent to the administrator for review.", article.id)
    db.commit()
    return {"id": article.id, "status": article.status}


@router.put("/articles/{article_id}")
def edit_article(article_id: int, title: str = Form(...), category_id: int = Form(...),
                 short_description: str = Form(...), content: str = Form(...),
                 location: str | None = Form(None), social_link: str | None = Form(None),
                 user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    a = _own(db, user, article_id)
    if a.status == "approved":
        raise HTTPException(403, "Published articles can only be edited by the administrator")
    _check_fields(db, title, category_id, short_description, content)
    a.title, a.category_id, a.short_description = title.strip(), category_id, short_description.strip()
    a.content = text_to_html(content)
    a.location, a.social_link = (location or "").strip() or None, _link(social_link)
    a.status, a.rejection_reason = "pending", None  # an edited submission goes back to review
    notify(db, user.id, f"Your submission «{a.title}» was updated and sent for review again.", a.id)
    db.commit()
    return {"id": a.id, "status": a.status}


@router.delete("/articles/{article_id}")
def delete_article(article_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    a = _own(db, user, article_id)
    if a.status == "approved":
        raise HTTPException(403, "Published articles can only be removed by the administrator")
    db.delete(a)
    db.commit()
    return {"ok": True}


# -------------------------------------------------------------- notifications
@router.get("/notifications")
def notifications(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    rows = (db.query(Notification).filter(Notification.user_id == user.id)
            .order_by(Notification.created_at.desc()).limit(50).all())
    return {"unread": sum(1 for n in rows if not n.is_read),
            "items": [{"id": n.id, "message": n.message, "is_read": n.is_read,
                       "created_at": n.created_at} for n in rows]}


@router.post("/notifications/read")
def read_notifications(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    db.query(Notification).filter(Notification.user_id == user.id, Notification.is_read.is_(False)).update({"is_read": True})
    db.commit()
    return {"ok": True}
