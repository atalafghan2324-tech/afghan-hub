"""PUBLIC API – the only place the website reads articles from.

Every query goes through `approved_query()`, so pending/rejected content can never be
returned from here, no matter what parameters a caller sends.
"""
from fastapi import APIRouter, Depends, HTTPException, Query, Response
from sqlalchemy import func, or_
from sqlalchemy.orm import Session, joinedload

from ..database import get_db
from ..models import Article, Category, User
from ..utils import card, get_settings_dict

router = APIRouter(prefix="/api", tags=["public"])


def approved_query(db: Session):
    return (db.query(Article).options(joinedload(Article.author), joinedload(Article.category))
            .filter(Article.status == "approved"))


def _cache(response: Response, seconds: int = 30):
    response.headers["Cache-Control"] = f"public, max-age={seconds}"


@router.get("/settings/public")
def public_settings(response: Response, db: Session = Depends(get_db)):
    _cache(response, 60)
    return get_settings_dict(db)


@router.get("/categories")
def categories(response: Response, db: Session = Depends(get_db)):
    _cache(response, 60)
    counts = dict(db.query(Article.category_id, func.count(Article.id))
                  .filter(Article.status == "approved").group_by(Article.category_id).all())
    return [{"id": c.id, "name": c.name, "slug": c.slug, "description": c.description,
             "count": counts.get(c.id, 0)} for c in db.query(Category).order_by(Category.name).all()]


@router.get("/articles")
def list_articles(response: Response, db: Session = Depends(get_db),
                  page: int = Query(1, ge=1), size: int = Query(9, ge=1, le=30),
                  category: str | None = None, q: str | None = Query(None, max_length=100),
                  sort: str = Query("latest", pattern="^(latest|popular)$")):
    _cache(response)
    query = (approved_query(db).join(User, Article.author_id == User.id)
             .outerjoin(Category, Article.category_id == Category.id))
    if category:
        query = query.filter(Category.slug == category)
    if q and q.strip():
        like = "%" + q.strip().replace("\\", "\\\\").replace("%", r"\%").replace("_", r"\_") + "%"
        query = (query
                 .filter(or_(Article.title.ilike(like), Article.short_description.ilike(like),
                             Article.content.ilike(like), User.name.ilike(like), Category.name.ilike(like))))
    total = query.count()
    order = Article.views.desc() if sort == "popular" else Article.approved_at.desc()
    items = query.order_by(order, Article.id.desc()).offset((page - 1) * size).limit(size).all()
    return {"items": [card(a) for a in items], "total": total, "page": page,
            "pages": max(1, -(-total // size))}


@router.get("/articles/featured")
def featured(response: Response, db: Session = Depends(get_db)):
    _cache(response)
    a = (approved_query(db).filter(Article.is_featured.is_(True))
         .order_by(Article.approved_at.desc()).first()
         or approved_query(db).order_by(Article.approved_at.desc()).first())
    return card(a) if a else None


@router.get("/articles/popular")
def popular(response: Response, db: Session = Depends(get_db), limit: int = Query(5, ge=1, le=20)):
    _cache(response)
    return [card(a) for a in approved_query(db).order_by(Article.views.desc(), Article.approved_at.desc()).limit(limit)]


@router.get("/articles/{category_slug}/{slug}")
def article_detail(category_slug: str, slug: str, db: Session = Depends(get_db)):
    a = approved_query(db).filter(Article.slug == slug).first()
    if not a:
        raise HTTPException(404, "Article not found")
    d = card(a)
    d.update(content=a.content, location=a.location, social_link=a.social_link,
             images=[{"url": i.image_url, "thumb": i.thumb_url} for i in a.images],
             author_info={"name": a.author.name, "bio": a.author.bio, "image": a.author.profile_image})
    return d
