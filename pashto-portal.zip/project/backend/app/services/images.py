"""Image validation, optimisation and storage.

Every upload is decoded with Pillow (so the real content is verified, not the file
extension), re-encoded as WebP (strips metadata/embedded payloads), resized, and then
stored on Cloudinary (production) or in ./uploads (local development).
"""
import io
import uuid
from pathlib import Path
from urllib.parse import urlparse

from fastapi import HTTPException, UploadFile
from PIL import Image, ImageOps, UnidentifiedImageError

from ..config import settings

Image.MAX_IMAGE_PIXELS = 30_000_000
ALLOWED_FORMATS = {"JPEG", "PNG", "WEBP"}
UPLOAD_DIR = Path(__file__).resolve().parents[2] / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

_cloud = False
if settings.CLOUDINARY_URL:
    import cloudinary
    import cloudinary.uploader

    u = urlparse(settings.CLOUDINARY_URL)
    cloudinary.config(cloud_name=u.hostname, api_key=u.username, api_secret=u.password, secure=True)
    _cloud = True


def _encode(img: Image.Image, max_side: int, quality: int) -> bytes:
    img = img.copy()
    img.thumbnail((max_side, max_side), Image.LANCZOS)
    buf = io.BytesIO()
    img.save(buf, "WEBP", quality=quality, method=4)
    return buf.getvalue()


def _store(data: bytes, folder: str) -> str:
    name = uuid.uuid4().hex
    if _cloud:
        res = cloudinary.uploader.upload(data, folder=folder, public_id=name,
                                         resource_type="image", format="webp")
        return res["secure_url"]
    d = UPLOAD_DIR / folder
    d.mkdir(parents=True, exist_ok=True)
    (d / f"{name}.webp").write_bytes(data)
    return f"/uploads/{folder}/{name}.webp"


def save_image(file: UploadFile, folder: str = "articles", thumb: bool = True) -> tuple[str, str | None]:
    """Returns (image_url, thumb_url)."""
    limit = settings.MAX_IMAGE_MB * 1024 * 1024
    raw = file.file.read(limit + 1)
    if not raw:
        raise HTTPException(400, "Empty image file")
    if len(raw) > limit:
        raise HTTPException(413, f"Image is larger than {settings.MAX_IMAGE_MB} MB")
    try:
        probe = Image.open(io.BytesIO(raw))
        probe.verify()
        img = Image.open(io.BytesIO(raw))
        if img.format not in ALLOWED_FORMATS:
            raise HTTPException(400, "Only JPG, JPEG, PNG and WEBP images are allowed")
        img = ImageOps.exif_transpose(img)
        img = img.convert("RGBA" if "A" in img.getbands() else "RGB")
    except HTTPException:
        raise
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError, ValueError):
        raise HTTPException(400, "Invalid or unsupported image file")

    url = _store(_encode(img, 1600, 82), folder)
    if not thumb:
        return url, None
    if _cloud:  # derive the thumbnail with a Cloudinary transformation
        return url, url.replace("/upload/", "/upload/c_limit,w_480,f_auto,q_auto/", 1)
    return url, _store(_encode(img, 480, 75), folder)
