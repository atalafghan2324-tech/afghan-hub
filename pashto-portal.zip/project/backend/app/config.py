from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    DATABASE_URL: str
    SECRET_KEY: str
    ACCESS_TOKEN_MINUTES: int = 30
    REFRESH_TOKEN_DAYS: int = 14
    COOKIE_SECURE: bool = False
    SITE_URL: str = "http://localhost:8000"
    CLOUDINARY_URL: str = ""
    CORS_ORIGINS: str = ""
    MAX_IMAGE_MB: int = 5


settings = Settings()
