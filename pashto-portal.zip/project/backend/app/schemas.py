from pydantic import BaseModel, EmailStr, Field, field_validator


class RegisterIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    email: EmailStr
    password: str = Field(min_length=8, max_length=72)
    phone: str | None = Field(default=None, max_length=40)

    @field_validator("name")
    @classmethod
    def strip_name(cls, v):
        return v.strip()


class LoginIn(BaseModel):
    email: EmailStr
    password: str = Field(max_length=72)


class ProfileUpdate(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    phone: str | None = Field(default=None, max_length=40)
    bio: str | None = Field(default=None, max_length=1000)


class PasswordChange(BaseModel):
    current_password: str
    new_password: str = Field(min_length=8, max_length=72)


class CategoryIn(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    slug: str | None = Field(default=None, max_length=120)
    description: str | None = Field(default=None, max_length=1000)


class RejectIn(BaseModel):
    reason: str = Field(min_length=3, max_length=2000)


class AdminArticleUpdate(BaseModel):
    title: str = Field(min_length=3, max_length=250)
    category_id: int | None = None
    short_description: str = Field(min_length=10, max_length=600)
    content: str = Field(min_length=10)
    location: str | None = Field(default=None, max_length=200)
    social_link: str | None = Field(default=None, max_length=500)
    is_featured: bool = False


class AdminUserUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=2, max_length=120)
    role: str | None = Field(default=None, pattern="^(user|admin)$")
    is_active: bool | None = None


class SettingsIn(BaseModel):
    values: dict[str, str]


def user_out(u) -> dict:
    return {"id": u.id, "name": u.name, "email": u.email, "phone": u.phone, "role": u.role,
            "profile_image": u.profile_image, "bio": u.bio, "is_active": u.is_active,
            "created_at": u.created_at}
