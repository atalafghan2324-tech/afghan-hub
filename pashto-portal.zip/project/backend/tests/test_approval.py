"""Proves the core rule: nothing is public until an admin approves it.
Run from backend/:  pytest -q   (uses a throw-away SQLite file, not your PostgreSQL DB)
"""
import io
import os

os.environ["DATABASE_URL"] = "sqlite:///./test.db"
os.environ["SECRET_KEY"] = "test-secret"

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402
from PIL import Image  # noqa: E402

from app.database import Base, SessionLocal, engine  # noqa: E402
from app.main import app  # noqa: E402
from app.models import Category, User  # noqa: E402
from app.security import hash_password  # noqa: E402


def png():
    buf = io.BytesIO()
    Image.new("RGB", (40, 30), "navy").save(buf, "PNG")
    return buf.getvalue()


@pytest.fixture(scope="module")
def client():
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    db = SessionLocal()
    db.add(Category(name="Tech", slug="technology"))
    db.add(User(name="Admin", email="admin@x.com", password_hash=hash_password("AdminPass123"), role="admin"))
    db.commit()
    db.close()
    with TestClient(app) as c:
        yield c


def auth(token):
    return {"Authorization": f"Bearer {token}"}


def submit(client, token, title):
    data = {"full_name": "Ali", "email": "ali@x.com", "phone": "0700", "title": title, "category_id": "1",
            "short_description": "A short description here", "content": "Some long enough content for the test article."}
    return client.post("/api/me/articles", data=data, headers=auth(token),
                       files={"main_image": ("a.png", png(), "image/png")})


def test_approval_flow(client):
    r = client.post("/api/auth/register", json={"name": "Ali", "email": "ali@x.com", "password": "UserPass123", "role": "admin"})
    assert r.status_code == 201 and r.json()["user"]["role"] == "user"   # cannot self-assign admin
    user_tok = r.json()["access_token"]
    admin_tok = client.post("/api/auth/login", json={"email": "admin@x.com", "password": "AdminPass123"}).json()["access_token"]

    assert submit(client, user_tok, "First article").status_code == 201
    mine = client.get("/api/me/articles", headers=auth(user_tok)).json()
    assert mine[0]["status"] == "pending"
    art_id, slug = mine[0]["id"], mine[0]["slug"]

    # pending content is invisible everywhere on the public side
    assert client.get("/api/articles").json()["total"] == 0
    assert client.get(f"/api/articles/technology/{slug}").status_code == 404
    assert client.get(f"/articles/technology/{slug}").status_code == 404
    assert client.get("/api/articles?q=First").json()["total"] == 0

    # a normal user cannot reach admin routes
    assert client.get("/api/admin/stats", headers=auth(user_tok)).status_code == 403
    assert client.post(f"/api/admin/articles/{art_id}/approve", headers=auth(user_tok)).status_code == 403
    assert client.get("/api/admin/stats").status_code == 401

    # admin approves -> public
    assert client.post(f"/api/admin/articles/{art_id}/approve", headers=auth(admin_tok)).status_code == 200
    assert client.get("/api/articles").json()["total"] == 1
    assert client.get(f"/articles/technology/{slug}").status_code == 200

    # reject flow with reason
    assert submit(client, user_tok, "Second article").status_code == 201
    second = [a for a in client.get("/api/me/articles", headers=auth(user_tok)).json() if a["title"] == "Second article"][0]
    assert client.post(f"/api/admin/articles/{second['id']}/reject", json={"reason": "Not enough sources"}, headers=auth(admin_tok)).status_code == 200
    seen = [a for a in client.get("/api/me/articles", headers=auth(user_tok)).json() if a["id"] == second["id"]][0]
    assert seen["status"] == "rejected" and seen["rejection_reason"] == "Not enough sources"
    assert client.get("/api/articles").json()["total"] == 1   # rejected stays hidden

    # other users cannot see or touch this user's submissions
    other = client.post("/api/auth/register", json={"name": "Bob", "email": "bob@x.com", "password": "UserPass123"}).json()["access_token"]
    assert client.get(f"/api/me/articles/{second['id']}", headers=auth(other)).status_code == 404
    assert client.delete(f"/api/me/articles/{second['id']}", headers=auth(other)).status_code == 404
    assert client.get("/api/me/articles", headers=auth(other)).json() == []


def test_rejects_non_images(client):
    tok = client.post("/api/auth/login", json={"email": "ali@x.com", "password": "UserPass123"}).json()["access_token"]
    data = {"full_name": "Ali", "email": "ali@x.com", "phone": "0700", "title": "Bad upload", "category_id": "1",
            "short_description": "A short description here", "content": "Some long enough content for the test article."}
    r = client.post("/api/me/articles", data=data, headers=auth(tok), files={"main_image": ("x.png", b"<?php echo 1;", "image/png")})
    assert r.status_code == 400
