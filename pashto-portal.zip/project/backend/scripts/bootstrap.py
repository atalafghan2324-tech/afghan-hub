"""Seeds default categories/settings and creates the first admin.

Usage (from the backend/ folder, after `alembic upgrade head`):
    python -m scripts.bootstrap --email admin@example.com --name "Admin" --password "StrongPass123"
"""
import argparse

from app.database import SessionLocal
from app.models import Category, SiteSetting, User
from app.security import hash_password

CATEGORIES = [("education", "ښوونه او روزنه"), ("technology", "ټکنالوژي"), ("society", "ټولنه"),
              ("health", "روغتیا"), ("economy", "اقتصاد"), ("culture", "کلتور"), ("history", "تاریخ"),
              ("experiences", "تجربې"), ("news", "خبرونه"), ("other", "نور")]
DEFAULTS = {"site_name": "پښتو پورټال", "site_tagline": "د پوهې او تجربو د شریکولو ځای",
            "about": "دا ویب پاڼه د معلوماتو، مقالو، ښوونیزو موضوعاتو او تجربو د شریکولو لپاره جوړه شوې ده.",
            "contact_email": "", "contact_phone": "", "contact_address": ""}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--email", required=True)
    p.add_argument("--name", default="Admin")
    p.add_argument("--password", required=True)
    args = p.parse_args()
    if len(args.password) < 8:
        raise SystemExit("Password must be at least 8 characters")
    db = SessionLocal()
    for slug, name in CATEGORIES:
        if not db.query(Category).filter(Category.name == name).first():
            db.add(Category(name=name, slug=slug))
    for k, v in DEFAULTS.items():
        if not db.get(SiteSetting, k):
            db.add(SiteSetting(key=k, value=v))
    email = args.email.lower()
    user = db.query(User).filter(User.email == email).first()
    if user:
        user.role, user.is_active = "admin", True
        print(f"Existing user {email} promoted to admin")
    else:
        db.add(User(name=args.name, email=email, password_hash=hash_password(args.password), role="admin"))
        print(f"Admin {email} created")
    db.commit()


if __name__ == "__main__":
    main()
