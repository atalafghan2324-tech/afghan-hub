(async () => {
  await App.layout("dashboard");
  if (!(await App.requireLogin())) return;
  const ST = { pending: "په انتظار کې", approved: "منظور شوې", rejected: "رد شوې" };
  let filter = "";

  // tabs
  App.$("#tabs").addEventListener("click", (e) => {
    const b = e.target.closest("button[data-t]"); if (!b) return;
    document.querySelectorAll("#tabs button").forEach((x) => x.classList.toggle("on", x === b));
    ["subs", "notes", "profile"].forEach((t) => App.$("#tab-" + t).classList.toggle("hidden", t !== b.dataset.t));
    if (b.dataset.t === "notes") loadNotes();
  });
  App.$("#filters").addEventListener("click", (e) => {
    const b = e.target.closest("button"); if (!b) return;
    filter = b.dataset.s;
    document.querySelectorAll("#filters button").forEach((x) => x.classList.toggle("on", x === b));
    loadSubs();
  });

  async function loadSubs() {
    const box = App.$("#subs"); box.innerHTML = App.skeleton(2);
    try {
      const items = await App.api("/me/articles" + (filter ? "?status=" + filter : ""));
      box.innerHTML = items.length ? items.map((a) => `
        <div class="sub">${a.thumb ? `<img loading="lazy" src="${App.esc(a.thumb)}" alt="">` : ""}
          <div style="flex:1;min-width:0"><h3 dir="auto">${App.esc(a.title)}</h3>
            <div class="meta"><span class="st ${a.status}">${ST[a.status]}</span><span>${App.fmtDate(a.created_at)}</span>${a.category ? `<span class="chip">${App.esc(a.category.name)}</span>` : ""}</div>
            ${a.status === "rejected" && a.rejection_reason ? `<div class="reason"><strong>د رد کولو دلیل:</strong> <span dir="auto">${App.esc(a.rejection_reason)}</span></div>` : ""}
            <div class="actions" style="margin-top:.6rem">
              ${a.status === "approved" ? `<a class="btn small" href="${App.href(a.url)}">مقاله وګورئ</a>` : `<a class="btn small" href="/submit.html?edit=${a.id}">سمول</a><button class="btn small danger" data-del="${a.id}">حذف</button>`}
            </div></div></div>`).join("")
        : App.empty(filter ? "پدې حالت کې کومه لیکنه نشته." : "تر اوسه مو کومه لیکنه نه ده لېږلې.");
    } catch (e) { box.innerHTML = App.errorState(e.message); }
  }
  App.$("#subs").addEventListener("click", async (e) => {
    const b = e.target.closest("[data-del]"); if (!b || !confirm("ایا ډاډه یاست چې دا لیکنه حذفوئ؟")) return;
    try { await App.api("/me/articles/" + b.dataset.del, { method: "DELETE" }); App.toast("لیکنه حذف شوه"); loadSubs(); }
    catch (err) { App.toast(err.message, true); }
  });

  async function loadNotes() {
    const box = App.$("#notes");
    try {
      const d = await App.api("/me/notifications");
      box.innerHTML = d.items.length ? d.items.map((n) => `<div class="item" style="${n.is_read ? "" : "font-weight:700"}"><div><div dir="auto">${App.esc(n.message)}</div><div class="meta">${App.fmtDate(n.created_at)}</div></div></div>`).join("") : App.empty("هېڅ خبرتیا نشته.");
      if (d.unread) { await App.api("/me/notifications/read", { method: "POST" }); App.$("#unread").textContent = ""; }
    } catch (e) { box.innerHTML = App.errorState(e.message); }
  }
  App.api("/me/notifications").then((d) => { if (d.unread) App.$("#unread").innerHTML = `<span class="badge">${d.unread}</span>`; }).catch(() => {});

  // profile
  const u = App.user;
  function fillProfile() {
    App.$("#p-name").value = u.name || ""; App.$("#p-email").value = u.email; App.$("#p-phone").value = u.phone || ""; App.$("#p-bio").value = u.bio || "";
    App.$("#avatar-row").innerHTML = u.profile_image ? `<img class="avatar" src="${App.esc(u.profile_image)}" alt="">` : `<span class="avatar ph">${App.esc((u.name || "?")[0])}</span>`;
  }
  fillProfile();
  App.$("#profile-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    try {
      Object.assign(u, await App.api("/me", { method: "PATCH", json: { name: App.$("#p-name").value, phone: App.$("#p-phone").value || null, bio: App.$("#p-bio").value || null } }));
      App.toast("پروفایل خوندي شو");
    } catch (err) { App.toast(err.message, true); }
  });
  App.$("#avatar").addEventListener("change", async (e) => {
    const f = e.target.files[0]; if (!f) return;
    if (f.size > 5 * 1024 * 1024) { App.toast("انځور باید تر ۵ MB کوچنی وي", true); return; }
    const fd = new FormData(); fd.append("file", f);
    try { Object.assign(u, await App.api("/me/avatar", { method: "POST", form: fd })); fillProfile(); App.toast("انځور بدل شو"); }
    catch (err) { App.toast(err.message, true); }
  });
  App.$("#pw-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    try {
      await App.api("/me/password", { method: "POST", json: { current_password: App.$("#pw-old").value, new_password: App.$("#pw-new").value } });
      e.target.reset(); App.toast("پټنوم بدل شو");
    } catch (err) { App.toast(err.message, true); }
  });
  loadSubs();
})();
