(async () => {
  App.layout("articles");
  App.sidebar(App.$("#sidebar"));
  const qs = new URLSearchParams(location.search);
  const form = App.$("#search-form"), list = App.$("#list"), count = App.$("#count");
  form.q.value = qs.get("q") || "";
  form.sort.value = qs.get("sort") === "popular" ? "popular" : "latest";
  try {
    const cats = await App.api("/categories");
    form.category.insertAdjacentHTML("beforeend", cats.map((c) => `<option value="${App.esc(c.slug)}">${App.esc(c.name)}</option>`).join(""));
    form.category.value = qs.get("category") || "";
  } catch (e) { /* filter stays empty */ }

  async function load(page) {
    list.innerHTML = App.skeleton(6); count.textContent = "";
    const p = new URLSearchParams({ page, size: 9, sort: form.sort.value });
    if (form.q.value.trim()) p.set("q", form.q.value.trim());
    if (form.category.value) p.set("category", form.category.value);
    try {
      const d = await App.api("/articles?" + p);
      list.innerHTML = d.items.length ? d.items.map(App.cardHTML).join("") : App.empty();
      count.textContent = d.total ? `${d.total} مقالې وموندل شوې` : "";
      App.pager(App.$("#pager"), d.page, d.pages, (n) => { load(n); window.scrollTo({ top: 0, behavior: "smooth" }); });
    } catch (e) { list.innerHTML = App.errorState(e.message); }
  }
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const p = new URLSearchParams();
    if (form.q.value.trim()) p.set("q", form.q.value.trim());
    if (form.category.value) p.set("category", form.category.value);
    if (form.sort.value !== "latest") p.set("sort", form.sort.value);
    history.replaceState(null, "", "?" + p);
    load(1);
  });
  load(+qs.get("page") || 1);
})();
