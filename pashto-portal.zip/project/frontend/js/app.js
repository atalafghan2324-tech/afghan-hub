/* Core helpers shared by every page: API client, auth, layout, cards. */
const App = (() => {
  let token = null, user = null, readyP = null, settingsP = null;

  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const $ = (sel, root = document) => root.querySelector(sel);
  const fmtDate = (d) => {
    if (!d) return "";
    try { return new Date(d).toLocaleDateString("ps-AF-u-ca-gregory", { year: "numeric", month: "long", day: "numeric" }); }
    catch (e) { return new Date(d).toLocaleDateString("en-GB"); }
  };
  const href = (u) => encodeURI(u);

  function toast(msg, isErr) {
    const t = document.createElement("div");
    t.className = "toast" + (isErr ? " err" : "");
    t.setAttribute("role", "status");
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 3800);
  }

  async function rawFetch(path, { method = "GET", json, form } = {}) {
    const headers = {};
    let body;
    if (token) headers.Authorization = "Bearer " + token;
    if (json !== undefined) { headers["Content-Type"] = "application/json"; body = JSON.stringify(json); }
    if (form) body = form;
    return fetch("/api" + path, { method, headers, body, credentials: "same-origin" });
  }

  async function refresh() {
    try {
      const r = await fetch("/api/auth/refresh", { method: "POST", credentials: "same-origin" });
      if (!r.ok) { localStorage.removeItem("hasSession"); return false; }
      const d = await r.json();
      token = d.access_token; user = d.user;
      return true;
    } catch (e) { return false; }
  }

  async function api(path, opts = {}) {
    let res = await rawFetch(path, opts);
    if (res.status === 401 && !path.startsWith("/auth/") && localStorage.getItem("hasSession") && (await refresh())) {
      res = await rawFetch(path, opts);
    }
    let data = null;
    try { data = await res.json(); } catch (e) { /* empty body */ }
    if (!res.ok) {
      let msg = data && data.detail;
      if (Array.isArray(msg)) msg = msg.map((m) => m.msg).join(" • ");
      throw new Error(msg || "ستونزه رامنځته شوه. بیا هڅه وکړئ.");
    }
    return data;
  }

  function setSession(d) { token = d.access_token; user = d.user; localStorage.setItem("hasSession", "1"); }

  async function logout() {
    try { await fetch("/api/auth/logout", { method: "POST", credentials: "same-origin" }); } catch (e) { /* ignore */ }
    token = user = null; localStorage.removeItem("hasSession");
    location.href = "/";
  }

  function ready() {
    if (!readyP) readyP = localStorage.getItem("hasSession") ? refresh() : Promise.resolve(false);
    return readyP;
  }
  const settings = () => (settingsP ||= fetch("/api/settings/public").then((r) => r.json()).catch(() => ({})));

  async function requireLogin() {
    await ready();
    if (!user) { location.href = "/login.html?next=" + encodeURIComponent(location.pathname + location.search); return false; }
    return true;
  }
  const safeNext = (n) => (n && n.startsWith("/") && !n.startsWith("//") ? n : null);

  /* ---------- layout ---------- */
  async function layout(active) {
    await ready();
    const s = await settings();
    const name = esc(s.site_name || "پښتو پورټال");
    const link = (id, url, label) => `<a href="${url}" class="${active === id ? "active" : ""}">${label}</a>`;
    const auth = user
      ? `<a href="/dashboard.html" class="${active === "dashboard" ? "active" : ""}">زما حساب</a>${user.role === "admin" ? '<a href="/admin.html">د مدیر پینل</a>' : ""}<button class="link" id="logout-btn" type="button">وتل</button>`
      : link("login", "/login.html", "ننوتل");
    $("#site-header").innerHTML = `<header class="topbar"><div class="container">
      <a class="brand" href="/">${s.site_logo ? `<img src="${esc(s.site_logo)}" alt="">` : ""}<span>${name}</span></a>
      <button class="burger" id="burger" aria-label="مینو" aria-expanded="false" type="button">☰</button>
      <nav class="nav" id="nav" aria-label="اصلي مینو">
        ${link("home", "/", "کور")}${link("articles", "/articles.html", "مقالې")}${link("topics", "/topics.html", "موضوعګانې")}
        ${link("popular", "/articles.html?sort=popular", "مشهورې مقالې")}${link("about", "/about.html", "زموږ په اړه")}${link("contact", "/contact.html", "اړیکه")}
        ${auth}<a class="cta" href="/submit.html">معلومات ولېږئ</a>
      </nav></div></header>`;
    $("#burger").onclick = () => { const o = $("#nav").classList.toggle("open"); $("#burger").setAttribute("aria-expanded", o); };
    const lo = $("#logout-btn"); if (lo) lo.onclick = logout;

    const soc = socials(s);
    $("#site-footer").innerHTML = `<footer class="footer"><div class="container"><div class="cols">
      <div><h3>${name}</h3><p dir="auto">${esc(s.about || "")}</p></div>
      <div><h3>چټک لینکونه</h3><ul><li><a href="/articles.html">مقالې</a></li><li><a href="/topics.html">موضوعګانې</a></li><li><a href="/submit.html">معلومات ولېږئ</a></li><li><a href="/contact.html">اړیکه</a></li></ul></div>
      <div><h3>ټولنیزې رسنۍ</h3>${soc || '<p class="muted">—</p>'}</div></div>
      <small>© ${new Date().getFullYear()} ${name}</small></div></footer>`;
  }

  function socials(s) {
    const map = { social_facebook: "Facebook", social_x: "X", social_youtube: "YouTube", social_telegram: "Telegram", social_whatsapp: "WhatsApp" };
    const out = Object.keys(map).filter((k) => s[k]).map((k) => `<a class="chip" target="_blank" rel="noopener noreferrer" href="${esc(s[k])}">${map[k]}</a>`);
    return out.length ? `<div class="social">${out.join("")}</div>` : "";
  }

  /* ---------- cards & states ---------- */
  const img = (a, cls = "") => ((a.thumb || a.image) ? `<img class="${cls}" loading="lazy" decoding="async" src="${esc(a.thumb || a.image)}" alt="${esc(a.title)}">` : `<div class="noimg ${cls}"></div>`);

  function cardHTML(a) {
    return `<a class="card" href="${href(a.url)}">${img(a)}<div class="card-body">
      ${a.category ? `<span class="chip" style="align-self:flex-start">${esc(a.category.name)}</span>` : ""}
      <h3 dir="auto">${esc(a.title)}</h3><p class="muted" dir="auto">${esc(a.short_description)}</p>
      <div class="meta"><span>${esc(a.author)}</span><span>${fmtDate(a.approved_at)}</span></div></div></a>`;
  }
  const itemHTML = (a) => `<a class="item" href="${href(a.url)}">${img(a)}<div><h4 dir="auto">${esc(a.title)}</h4><div class="meta"><span>${fmtDate(a.approved_at)}</span><span>${a.views} 👁</span></div></div></a>`;
  const skeleton = (n = 6) => Array.from({ length: n }, () => '<div class="skel"></div>').join("");
  const empty = (msg = "هېڅ مقاله و نه موندل شوه.") => `<div class="state"><div class="big">📭</div><p>${esc(msg)}</p></div>`;
  const errorState = (msg) => `<div class="state"><div class="big">⚠️</div><p>${esc(msg)}</p><button class="btn" onclick="location.reload()">بیا هڅه وکړئ</button></div>`;

  function pager(el, page, pages, go) {
    if (pages <= 1) { el.innerHTML = ""; return; }
    let h = "";
    for (let p = 1; p <= pages; p++) {
      if (p === 1 || p === pages || Math.abs(p - page) <= 2) h += `<button class="btn small ${p === page ? "cur" : ""}" data-p="${p}">${p}</button>`;
      else if (Math.abs(p - page) === 3) h += "<span>…</span>";
    }
    el.innerHTML = h;
    el.querySelectorAll("button").forEach((b) => (b.onclick = () => go(+b.dataset.p)));
  }

  async function sidebar(el) {
    el.innerHTML = '<div class="widget skel"></div>';
    try {
      const [s, pop, recent, cats] = await Promise.all([settings(), api("/articles/popular?limit=5"), api("/articles?size=5"), api("/categories")]);
      el.innerHTML = `
        <section class="widget"><h3>د ویب پاڼې په اړه</h3><p dir="auto">${esc(s.about || "")}</p></section>
        <section class="widget"><h3>مشهورې مقالې</h3>${pop.length ? pop.map(itemHTML).join("") : '<p class="muted">تر اوسه مقاله نشته.</p>'}</section>
        <section class="widget"><h3>وروستۍ مقالې</h3>${recent.items.length ? recent.items.map(itemHTML).join("") : '<p class="muted">تر اوسه مقاله نشته.</p>'}</section>
        <section class="widget"><h3>کټګورۍ</h3><ul class="cat-list">${cats.map((c) => `<li><a href="/articles.html?category=${encodeURIComponent(c.slug)}"><span>${esc(c.name)}</span><span class="muted">${c.count}</span></a></li>`).join("")}</ul></section>
        ${socials(s) ? `<section class="widget"><h3>موږ تعقیب کړئ</h3>${socials(s)}</section>` : ""}`;
    } catch (e) { el.innerHTML = ""; }
  }

  return { api, esc, $, fmtDate, href, toast, ready, settings, layout, sidebar, cardHTML, itemHTML, skeleton, empty, errorState, pager,
    requireLogin, safeNext, setSession, logout, refresh, get user() { return user; }, set user(u) { user = u; } };
})();
