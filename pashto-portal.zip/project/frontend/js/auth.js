(async () => {
  await App.layout(location.pathname.includes("register") ? "register" : "login");
  const next = App.safeNext(new URLSearchParams(location.search).get("next"));
  if (App.user) { location.replace(next || "/dashboard.html"); return; }
  const login = App.$("#login-form"), reg = App.$("#register-form"), msg = App.$("#msg");
  const form = login || reg;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    msg.innerHTML = "";
    const f = new FormData(form), btn = form.querySelector("button[type=submit]");
    const body = Object.fromEntries(f.entries());
    if (!body.email || !body.password) { msg.innerHTML = '<div class="alert err">بریښنالیک او پټنوم ولیکئ.</div>'; return; }
    if (reg && body.password.length < 8) { msg.innerHTML = '<div class="alert err">پټنوم باید لږ تر لږه ۸ توري ولري.</div>'; return; }
    btn.disabled = true;
    try {
      const d = await App.api(login ? "/auth/login" : "/auth/register", { method: "POST", json: body });
      App.setSession(d);
      location.href = next || (d.user.role === "admin" ? "/admin.html" : "/dashboard.html");
    } catch (err) {
      msg.innerHTML = `<div class="alert err">${App.esc(err.message)}</div>`;
      btn.disabled = false;
    }
  });
})();
