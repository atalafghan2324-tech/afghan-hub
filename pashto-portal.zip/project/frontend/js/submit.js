(async () => {
  await App.layout("submit");
  if (!(await App.requireLogin())) return;
  const form = App.$("#submit-form"), msg = App.$("#msg"), done = App.$("#done");
  const editId = new URLSearchParams(location.search).get("edit");
  const MAX = 5 * 1024 * 1024, OK = ["image/jpeg", "image/png", "image/webp"];

  const cats = await App.api("/categories");
  form.category_id.innerHTML = '<option value="">— وټاکئ —</option>' + cats.map((c) => `<option value="${c.id}">${App.esc(c.name)}</option>`).join("");
  form.full_name.value = App.user.name || ""; form.email.value = App.user.email || ""; form.phone.value = App.user.phone || "";

  if (editId) {   // edit a pending / rejected submission
    App.$("#form-title").textContent = "لیکنه سمول";
    App.$("#image-fields").classList.add("hidden");
    try {
      const a = await App.api("/me/articles/" + encodeURIComponent(editId));
      form.title.value = a.title; form.category_id.value = a.category_id || ""; form.short_description.value = a.short_description;
      form.content.value = (a.content_text || "").replace(/<br\s*\/?>/g, "\n").replace(/<\/p><p>/g, "\n\n").replace(/<[^>]+>/g, "")
        .replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#x27;|&#39;/g, "'").replace(/&amp;/g, "&");
      form.location.value = a.location || ""; form.social_link.value = a.social_link || "";
    } catch (e) { msg.innerHTML = `<div class="alert err">${App.esc(e.message)}</div>`; }
  }

  function validate() {
    for (const f of ["full_name", "email", "phone", "category_id", "title", "short_description", "content"]) {
      if (!form[f].value.trim()) return "ټول اړین ډګرونه ډک کړئ (*).";
    }
    if (form.short_description.value.trim().length < 10) return "لنډ تشریح باید لږ تر لږه ۱۰ توري ولري.";
    if (form.content.value.trim().length < 30) return "منځپانګه ډیره لنډه ده.";
    if (!editId) {
      const files = [form.main_image.files[0], ...form.extra_images.files].filter(Boolean);
      if (!form.main_image.files[0]) return "اصلي انځور اړین دی.";
      if (form.extra_images.files.length > 8) return "تر ۸ زیات اضافي انځورونه نشي لیږل کېدای.";
      for (const f of files) {
        if (!OK.includes(f.type)) return "یوازې JPG، PNG او WEBP انځورونه منل کېږي.";
        if (f.size > MAX) return "هر انځور باید تر ۵ MB کوچنی وي.";
      }
    }
    return "";
  }

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    msg.innerHTML = "";
    const err = validate();
    if (err) { msg.innerHTML = `<div class="alert err">${err}</div>`; return; }
    const btn = App.$("#send"); btn.disabled = true; btn.textContent = "په لېږلو کې…";
    try {
      const fd = new FormData(form);
      if (editId) { fd.delete("main_image"); fd.delete("extra_images"); fd.delete("full_name"); fd.delete("email"); fd.delete("phone"); }
      await App.api(editId ? "/me/articles/" + encodeURIComponent(editId) : "/me/articles", { method: editId ? "PUT" : "POST", form: fd });
      form.classList.add("hidden");
      done.classList.remove("hidden");
      done.innerHTML = `<div class="alert ok"><strong>ستاسو معلومات په بریالیتوب سره د مدیر ته د کتنې لپاره ولېږل شول.</strong><br>کله چې منظور شي، به په عامه ویب پاڼه کې خپور شي. حالت تاسو په خپل حساب کې کتلای شئ.</div><p><a class="btn primary" href="/dashboard.html">زما لیکنې</a> <a class="btn" href="/submit.html">بله لیکنه</a></p>`;
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (e2) {
      msg.innerHTML = `<div class="alert err">${App.esc(e2.message)}</div>`;
      btn.disabled = false; btn.textContent = "لېږل";
    }
  });
})();
