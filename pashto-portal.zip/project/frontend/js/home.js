(async () => {
  App.layout("home");
  App.sidebar(App.$("#sidebar"));
  const latest = App.$("#latest"), cats = App.$("#cats"), hero = App.$("#hero");
  latest.innerHTML = App.skeleton(6);
  try {
    const [f, list, c] = await Promise.all([App.api("/articles/featured"), App.api("/articles?size=6"), App.api("/categories")]);
    hero.innerHTML = f
      ? `<a class="hero" href="${App.href(f.url)}">${f.image ? `<img src="${App.esc(f.image)}" alt="${App.esc(f.title)}" fetchpriority="high">` : ""}
          <div class="hero-body"><span class="badge">ځانګړې مقاله</span><h1 dir="auto">${App.esc(f.title)}</h1><p dir="auto">${App.esc(f.short_description)}</p></div></a>`
      : `<div class="panel state"><div class="big">✍️</div><h2>لومړۍ مقاله ستاسو وي</h2><p>خپل معلومات ولېږئ؛ د مدیر له منظورۍ وروسته به دلته خپاره شي.</p><a class="btn primary" href="/submit.html">معلومات ولېږئ</a></div>`;
    latest.innerHTML = list.items.length ? list.items.map(App.cardHTML).join("") : App.empty("تر اوسه کومه خپره شوې مقاله نشته.");
    cats.innerHTML = c.map((x) => `<a class="cat-tile" href="/articles.html?category=${encodeURIComponent(x.slug)}"><h3>${App.esc(x.name)}</h3><span class="chip">${x.count} مقالې</span></a>`).join("");
  } catch (e) {
    hero.innerHTML = ""; latest.innerHTML = App.errorState(e.message);
  }
})();
