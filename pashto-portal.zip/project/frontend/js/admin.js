(async () => {
  await App.layout("admin");
  if (!(await App.requireLogin())) return;
  if (App.user.role !== "admin") { App.$("main").innerHTML = '<div class="state"><div class="big">🔒</div><h2>دا پاڼه یوازې د مدیر لپاره ده.</h2><a class="btn" href="/">کور ته ستنېدل</a></div>'; return; }

  const E = App.esc, view = App.$("#view"), dlg = App.$("#dlg"), body = App.$("#dlg-body");
  const ST = { pending: "په انتظار کې", approved: "منظور شوې", rejected: "رد شوې" };
  const IMG_OK = ["image/jpeg", "image/png", "image/webp"];
  let current = "stats", cats = [];
  const openDlg = (html) => { body.innerHTML = html; if (!dlg.open) dlg.showModal(); };
  const closeDlg = () => dlg.open && dlg.close();
  dlg.addEventListener("click", (e) => { if (e.target === dlg) closeDlg(); });
  const fail = (e) => App.toast(e.message, true);
  const loadCats = async () => (cats = await App.api("/categories"));
  const catOptions = (sel) => '<option value="">— بې کټګورۍ —</option>' + cats.map((c) => `<option value="${c.id}" ${c.id === sel ? "selected" : ""}>${E(c.name)}</option>`).join("");

  async function pendingCount() {
    try { const s = await App.api("/admin/stats"); App.$("#pend-n").innerHTML = s.pending ? `<span class="badge">${s.pending}</span>` : ""; return s; } catch (e) { return null; }
  }
  async function go(v) {
    current = v;
    document.querySelectorAll("#admin-nav button").forEach((b) => b.classList.toggle("on", b.dataset.v === v));
    view.innerHTML = App.skeleton(2);
    try { await views[v](); } catch (e) { view.innerHTML = App.errorState(e.message); }
    pendingCount();
  }
  App.$("#admin-nav").addEventListener("click", (e) => { const b = e.target.closest("button"); if (b) go(b.dataset.v); });

  /* ------------------------------------------------------------ views */
  const views = {
    async stats() {
      const s = await pendingCount();
      const t = (n, l, c = "") => `<div class="stat ${c}"><b>${n}</b>${l}</div>`;
      view.innerHTML = `<h1>ډیشبورډ</h1><div class="stats">${t(s.users, "ټول کاروونکي")}${t(s.articles, "ټولې مقالې")}${t(s.pending, "په انتظار کې", "warn")}${t(s.approved, "منظورې شوې")}${t(s.rejected, "رد شوې")}${t(s.categories, "ټولې کټګورۍ")}</div>
        ${s.pending ? `<p style="margin-top:1.5rem"><button class="btn primary" onclick="document.querySelector('[data-v=pending]').click()">${s.pending} لیکنې د کتنې په تمه دي</button></p>` : ""}`;
    },
    pending: () => articlesView("pending"),
    articles: () => articlesView(""),

    async users() {
      let page = 1, q = "";
      view.innerHTML = `<h1>کاروونکي</h1><form class="search" id="uf"><input name="q" placeholder="د نوم یا بریښنالیک له مخې لټون"><button class="btn" type="submit">لټون</button></form><div class="panel tbl-wrap" id="ulist"></div><div class="pager" id="upager"></div>`;
      async function load() {
        const d = await App.api(`/admin/users?page=${page}&q=${encodeURIComponent(q)}`);
        App.$("#ulist").innerHTML = d.items.length ? `<table><thead><tr><th>نوم</th><th>بریښنالیک</th><th>رول</th><th>حالت</th><th>نېټه</th><th></th></tr></thead><tbody>${d.items.map((u) => `<tr>
          <td>${E(u.name)}</td><td dir="ltr">${E(u.email)}</td><td>${u.role === "admin" ? "مدیر" : "کاروونکی"}</td>
          <td><span class="st ${u.is_active ? "approved" : "rejected"}">${u.is_active ? "فعال" : "بند"}</span></td><td>${App.fmtDate(u.created_at)}</td>
          <td class="actions"><button class="btn small" data-act="u-role" data-id="${u.id}" data-v="${u.role === "admin" ? "user" : "admin"}">${u.role === "admin" ? "عادي کول" : "مدیر کول"}</button>
          <button class="btn small" data-act="u-active" data-id="${u.id}" data-v="${u.is_active ? 0 : 1}">${u.is_active ? "بندول" : "فعالول"}</button>
          <button class="btn small danger" data-act="u-del" data-id="${u.id}">حذف</button></td></tr>`).join("")}</tbody></table>` : App.empty("کاروونکی ونه موندل شو.");
        App.pager(App.$("#upager"), d.page, d.pages, (n) => { page = n; load().catch(fail); });
      }
      App.$("#uf").addEventListener("submit", (e) => { e.preventDefault(); q = e.target.q.value; page = 1; load().catch(fail); });
      await load();
    },

    async categories() {
      await loadCats();
      view.innerHTML = `<div class="dlg-head"><h1>کټګورۍ</h1><button class="btn primary" data-act="cat-form">نوې کټګوري</button></div>
        <div class="panel tbl-wrap"><table><thead><tr><th>نوم</th><th>Slug</th><th>تشریح</th><th>مقالې</th><th></th></tr></thead><tbody>${cats.map((c) => `<tr><td>${E(c.name)}</td><td dir="ltr">${E(c.slug)}</td><td dir="auto">${E(c.description || "")}</td><td>${c.count}</td>
        <td class="actions"><button class="btn small" data-act="cat-form" data-id="${c.id}">سمول</button><button class="btn small danger" data-act="cat-del" data-id="${c.id}">حذف</button></td></tr>`).join("")}</tbody></table></div>`;
    },

    async settings() {
      const s = await App.api("/admin/settings");
      const f = (k, l, t = "text") => `<label for="s-${k}">${l}</label><input id="s-${k}" data-k="${k}" type="${t}" value="${E(s[k] || "")}" dir="auto">`;
      view.innerHTML = `<h1>د ویب پاڼې تنظیمات</h1><div class="panel form">
        ${f("site_name", "د ویب پاڼې نوم")}${f("site_tagline", "شعار")}
        <label>لوګو</label><div style="display:flex;gap:1rem;align-items:center">${s.site_logo ? `<img src="${E(s.site_logo)}" alt="" style="height:48px">` : ""}<input type="file" id="logo" accept="image/jpeg,image/png,image/webp"></div>
        <label for="s-about">د ویب پاڼې په اړه</label><textarea id="s-about" data-k="about" dir="auto">${E(s.about || "")}</textarea>
        <div class="row2"><div>${f("contact_email", "د اړیکې بریښنالیک", "email")}</div><div>${f("contact_phone", "تلیفون")}</div></div>${f("contact_address", "پته")}
        ${f("social_facebook", "Facebook (URL)", "url")}${f("social_x", "X / Twitter (URL)", "url")}${f("social_youtube", "YouTube (URL)", "url")}${f("social_telegram", "Telegram (URL)", "url")}${f("social_whatsapp", "WhatsApp (URL)", "url")}
        <p><button class="btn primary" id="save-settings">خوندي کول</button></p></div>`;
      App.$("#save-settings").onclick = async () => {
        const values = {}; view.querySelectorAll("[data-k]").forEach((i) => (values[i.dataset.k] = i.value.trim()));
        try { await App.api("/admin/settings", { method: "PUT", json: { values } }); App.toast("تنظیمات خوندي شول"); } catch (e) { fail(e); }
      };
      App.$("#logo").onchange = async (e) => {
        const file = e.target.files[0]; if (!file) return;
        const fd = new FormData(); fd.append("file", file);
        try { await App.api("/admin/settings/logo", { method: "POST", form: fd }); App.toast("لوګو خوندي شو"); go("settings"); } catch (er) { fail(er); }
      };
    },
  };

  async function articlesView(fixed) {
    let page = 1, status = fixed, q = "";
    view.innerHTML = `<div class="dlg-head"><h1>${fixed ? "په انتظار کې لیکنې" : "ټولې مقالې"}</h1><button class="btn primary" data-act="edit">نوې مقاله</button></div>
      ${fixed ? "" : `<form class="search" id="af"><input name="q" placeholder="د سرلیک له مخې لټون"><select name="status"><option value="">ټول حالتونه</option><option value="pending">په انتظار کې</option><option value="approved">منظورې شوې</option><option value="rejected">رد شوې</option></select><button class="btn" type="submit">لټون</button></form>`}
      <div id="alist"></div><div class="pager" id="apager"></div>`;
    async function load() {
      App.$("#alist").innerHTML = App.skeleton(2);
      const d = await App.api(`/admin/articles?page=${page}&status=${status}&q=${encodeURIComponent(q)}`);
      App.$("#alist").innerHTML = d.items.length ? d.items.map((a) => `<div class="sub">${a.thumb ? `<img loading="lazy" src="${E(a.thumb)}" alt="">` : ""}
        <div style="flex:1;min-width:0"><h3 dir="auto">${E(a.title)}</h3>
        <div class="meta"><span class="st ${a.status}">${ST[a.status]}</span><span>${E(a.author)}</span>${a.category ? `<span class="chip">${E(a.category.name)}</span>` : ""}<span>${App.fmtDate(a.created_at)}</span></div>
        <div class="actions" style="margin-top:.6rem"><button class="btn small" data-act="review" data-id="${a.id}">کتنه</button>
        ${a.status !== "approved" ? `<button class="btn small ok" data-act="approve" data-id="${a.id}">منل</button>` : ""}${a.status !== "rejected" ? `<button class="btn small danger" data-act="reject" data-id="${a.id}">رد کول</button>` : ""}
        <button class="btn small" data-act="edit" data-id="${a.id}">سمول</button><button class="btn small danger" data-act="del" data-id="${a.id}">حذف</button></div></div></div>`).join("") : App.empty(fixed ? "هیڅ لیکنه د کتنې په تمه نه ده. 🎉" : "مقاله ونه موندل شوه.");
      App.pager(App.$("#apager"), d.page, d.pages, (n) => { page = n; load().catch(fail); });
    }
    const af = App.$("#af");
    if (af) af.addEventListener("submit", (e) => { e.preventDefault(); q = af.q.value; status = af.status.value; page = 1; load().catch(fail); });
    await load();
  }

  /* ------------------------------------------------------------ dialogs */
  async function review(id) {
    const a = await App.api("/admin/articles/" + id);
    openDlg(`<div class="dlg-head"><h2 dir="auto">${E(a.title)}</h2><button class="btn small" data-act="close">✕</button></div>
      <div class="meta" style="margin-block:.5rem"><span class="st ${a.status}">${ST[a.status]}</span><span>لیکوال: ${E(a.author)} (${E(a.author_email || "")})</span>${a.category ? `<span class="chip">${E(a.category.name)}</span>` : ""}<span>${App.fmtDate(a.created_at)}</span></div>
      <div class="meta"><span>نوم: ${E(a.contact_name || "—")}</span><span dir="ltr">${E(a.contact_email || "")}</span><span dir="ltr">${E(a.contact_phone || "")}</span>${a.location ? `<span>📍 ${E(a.location)}</span>` : ""}${a.social_link ? `<a href="${E(a.social_link)}" target="_blank" rel="noopener noreferrer nofollow">ټولنیز لینک</a>` : ""}</div>
      ${a.rejection_reason ? `<div class="reason"><strong>د رد دلیل:</strong> ${E(a.rejection_reason)}</div>` : ""}
      ${a.image ? `<img class="hero-img" src="${E(a.image)}" alt="">` : ""}
      <p class="lead" dir="auto">${E(a.short_description)}</p><div class="prose" dir="auto">${a.content}</div>
      ${a.images.length ? `<div class="gallery">${a.images.map((i) => `<a href="${E(i.url)}" target="_blank" rel="noopener"><img loading="lazy" src="${E(i.thumb || i.url)}" alt=""></a>`).join("")}</div>` : ""}
      <div class="actions" style="margin-top:1rem">${a.status !== "approved" ? `<button class="btn ok" data-act="approve" data-id="${a.id}">منل</button>` : ""}${a.status !== "rejected" ? `<button class="btn danger" data-act="reject" data-id="${a.id}">رد کول</button>` : ""}
      <button class="btn" data-act="edit" data-id="${a.id}">سمول</button><button class="btn danger" data-act="del" data-id="${a.id}">حذف</button></div>`);
  }

  function rejectForm(id) {
    openDlg(`<h2>د رد کولو دلیل</h2><p class="muted">دا دلیل به کاروونکی په خپل حساب کې وویني.</p>
      <label for="why">دلیل *</label><textarea id="why" dir="auto" maxlength="2000"></textarea><div id="rmsg"></div>
      <p class="actions"><button class="btn danger" id="do-reject">رد کول</button><button class="btn" data-act="close">لغوه</button></p>`);
    App.$("#do-reject").onclick = async () => {
      const reason = App.$("#why").value.trim();
      if (reason.length < 3) { App.$("#rmsg").innerHTML = '<div class="alert err">دلیل ولیکئ.</div>'; return; }
      try { await App.api(`/admin/articles/${id}/reject`, { method: "POST", json: { reason } }); closeDlg(); App.toast("لیکنه رد شوه"); go(current); } catch (e) { fail(e); }
    };
  }

  async function editor(id) {
    await loadCats();
    const a = id ? await App.api("/admin/articles/" + id) : null;
    openDlg(`<div class="dlg-head"><h2>${a ? "مقاله سمول" : "نوې مقاله"}</h2><button class="btn small" data-act="close">✕</button></div>
      <label for="e-title">سرلیک *</label><input id="e-title" dir="auto" maxlength="250" value="${E(a ? a.title : "")}">
      <div class="row2"><div><label for="e-cat">کټګوري</label><select id="e-cat">${catOptions(a && a.category_id)}</select></div><div><label for="e-loc">موقعیت</label><input id="e-loc" dir="auto" value="${E(a ? a.location || "" : "")}"></div></div>
      <label for="e-desc">لنډ تشریح *</label><textarea id="e-desc" dir="auto" style="min-height:80px" maxlength="600">${E(a ? a.short_description : "")}</textarea>
      <label>بشپړه منځپانګه *</label><div id="quill"></div>
      <label for="e-soc">ټولنیزې رسنۍ لینک</label><input id="e-soc" type="url" dir="ltr" value="${E(a ? a.social_link || "" : "")}">
      <label>${a ? "اصلي انځور بدلول" : "اصلي انځور"}</label>${a && a.image ? `<img src="${E(a.thumb || a.image)}" alt="" style="height:80px;border-radius:10px;margin-bottom:.4rem">` : ""}<input type="file" id="e-main" accept="image/jpeg,image/png,image/webp">
      ${a ? `<label>اضافي انځورونه</label><div class="thumbs" id="thumbs">${thumbs(a)}</div><input type="file" id="e-extra" accept="image/jpeg,image/png,image/webp">` : ""}
      <label style="display:flex;gap:.5rem;align-items:center"><input type="checkbox" id="e-feat" ${a && a.is_featured ? "checked" : ""}> په کور پاڼه کې د ځانګړې مقالې په توګه ښودل</label>
      <div id="emsg"></div><p class="actions"><button class="btn primary" id="e-save">خوندي کول</button><button class="btn" data-act="close">لغوه</button></p>`);

    const quill = new Quill("#quill", { theme: "snow", modules: { toolbar: { container: [[{ header: [2, 3, 4, false] }], ["bold", "italic", "underline"], [{ list: "ordered" }, { list: "bullet" }], ["blockquote", "link", "image"], [{ align: [] }, { direction: "rtl" }], ["clean"]],
      handlers: { image() {
        const inp = document.createElement("input"); inp.type = "file"; inp.accept = IMG_OK.join(",");
        inp.onchange = async () => {
          const f = inp.files[0]; if (!f) return;
          const fd = new FormData(); fd.append("file", f);
          try { const r = await App.api("/admin/upload-image", { method: "POST", form: fd }); const pos = (quill.getSelection(true) || { index: quill.getLength() }).index; quill.insertEmbed(pos, "image", r.url); } catch (e) { fail(e); }
        };
        inp.click();
      } } } } });
    if (a) quill.root.innerHTML = a.content;

    const extra = App.$("#e-extra");
    if (extra) extra.onchange = async () => {
      const f = extra.files[0]; if (!f) return; const fd = new FormData(); fd.append("file", f);
      try { await App.api(`/admin/articles/${id}/images`, { method: "POST", form: fd }); const n = await App.api("/admin/articles/" + id); App.$("#thumbs").innerHTML = thumbs(n); extra.value = ""; } catch (e) { fail(e); }
    };
    App.$("#thumbs") && App.$("#thumbs").addEventListener("click", async (e) => {
      const b = e.target.closest("[data-delimg]"); if (!b) return;
      try { await App.api(`/admin/articles/${id}/images/${b.dataset.delimg}`, { method: "DELETE" }); b.closest("figure").remove(); } catch (er) { fail(er); }
    });

    App.$("#e-save").onclick = async () => {
      const m = App.$("#emsg"), btn = App.$("#e-save"); m.innerHTML = "";
      const title = App.$("#e-title").value.trim(), desc = App.$("#e-desc").value.trim(), html = quill.root.innerHTML, empty = quill.getText().trim().length < 10;
      if (title.length < 3 || desc.length < 10 || empty) { m.innerHTML = '<div class="alert err">سرلیک، لنډ تشریح او منځپانګه ډک کړئ.</div>'; return; }
      const main = App.$("#e-main").files[0];
      if (main && (!IMG_OK.includes(main.type) || main.size > 5 * 1024 * 1024)) { m.innerHTML = '<div class="alert err">انځور باید JPG/PNG/WEBP او تر ۵ MB کوچنی وي.</div>'; return; }
      const cat = App.$("#e-cat").value, loc = App.$("#e-loc").value.trim(), soc = App.$("#e-soc").value.trim(), feat = App.$("#e-feat").checked;
      btn.disabled = true;
      try {
        if (a) {
          await App.api("/admin/articles/" + id, { method: "PUT", json: { title, category_id: cat ? +cat : null, short_description: desc, content: html, location: loc || null, social_link: soc || null, is_featured: feat } });
          if (main) { const fd = new FormData(); fd.append("file", main); await App.api(`/admin/articles/${id}/main-image`, { method: "POST", form: fd }); }
        } else {
          const fd = new FormData();
          Object.entries({ title, short_description: desc, content: html, is_featured: feat }).forEach(([k, v]) => fd.append(k, v));
          if (cat) fd.append("category_id", cat); if (loc) fd.append("location", loc); if (soc) fd.append("social_link", soc); if (main) fd.append("main_image", main);
          await App.api("/admin/articles", { method: "POST", form: fd });
        }
        closeDlg(); App.toast("خوندي شو"); go(current);
      } catch (e) { m.innerHTML = `<div class="alert err">${E(e.message)}</div>`; btn.disabled = false; }
    };
  }
  const thumbs = (a) => a.images.map((i) => `<figure><img src="${E(i.thumb || i.url)}" alt=""><button class="btn small danger" style="position:absolute;inset-block-start:2px;inset-inline-end:2px;min-height:28px;padding:0 .5rem" data-delimg="${i.id}" type="button">✕</button></figure>`).join("");

  function catForm(id) {
    const c = id ? cats.find((x) => x.id === +id) : null;
    openDlg(`<h2>${c ? "کټګوري سمول" : "نوې کټګوري"}</h2><label for="c-name">نوم *</label><input id="c-name" value="${E(c ? c.name : "")}" dir="auto">
      <label for="c-slug">Slug (د URL لپاره، اختیاري)</label><input id="c-slug" dir="ltr" value="${E(c ? c.slug : "")}"><label for="c-desc">تشریح</label><textarea id="c-desc" dir="auto" style="min-height:80px">${E(c ? c.description || "" : "")}</textarea>
      <div id="cmsg"></div><p class="actions"><button class="btn primary" id="c-save">خوندي کول</button><button class="btn" data-act="close">لغوه</button></p>`);
    App.$("#c-save").onclick = async () => {
      const json = { name: App.$("#c-name").value.trim(), slug: App.$("#c-slug").value.trim() || null, description: App.$("#c-desc").value.trim() || null };
      if (json.name.length < 2) { App.$("#cmsg").innerHTML = '<div class="alert err">نوم ولیکئ.</div>'; return; }
      try { await App.api(c ? "/admin/categories/" + c.id : "/admin/categories", { method: c ? "PUT" : "POST", json }); closeDlg(); App.toast("خوندي شو"); go("categories"); }
      catch (e) { App.$("#cmsg").innerHTML = `<div class="alert err">${E(e.message)}</div>`; }
    };
  }

  /* ------------------------------------------------------------ actions */
  document.addEventListener("click", async (e) => {
    const b = e.target.closest("[data-act]"); if (!b) return;
    const { act, id } = b.dataset;
    try {
      if (act === "close") closeDlg();
      else if (act === "review") await review(id);
      else if (act === "edit") await editor(id || null);
      else if (act === "reject") rejectForm(id);
      else if (act === "approve") { await App.api(`/admin/articles/${id}/approve`, { method: "POST" }); closeDlg(); App.toast("مقاله خپره شوه"); go(current); }
      else if (act === "del") { if (confirm("ایا ډاډه یاست چې دا مقاله حذفوئ؟")) { await App.api("/admin/articles/" + id, { method: "DELETE" }); closeDlg(); App.toast("حذف شو"); go(current); } }
      else if (act === "u-role") { await App.api("/admin/users/" + id, { method: "PATCH", json: { role: b.dataset.v } }); go("users"); }
      else if (act === "u-active") { await App.api("/admin/users/" + id, { method: "PATCH", json: { is_active: b.dataset.v === "1" } }); go("users"); }
      else if (act === "u-del") { if (confirm("دا کاروونکی او ټولې لیکنې یې به حذف شي. ډاډه یاست؟")) { await App.api("/admin/users/" + id, { method: "DELETE" }); go("users"); } }
      else if (act === "cat-form") { await loadCats(); catForm(id); }
      else if (act === "cat-del") { if (confirm("دا کټګوري حذفوئ؟ مقالې به پاتې شي.")) { await App.api("/admin/categories/" + id, { method: "DELETE" }); go("categories"); } }
    } catch (err) { fail(err); }
  });

  go("stats");
})();
