# Pashto Information Portal

A Pashto-first (RTL) information-sharing website. Visitors read articles; registered users submit articles with images; **nothing becomes public until an admin approves it** — enforced in the backend and database, not just the UI.

**Stack:** HTML + CSS + vanilla JavaScript · FastAPI (Python) · PostgreSQL · Cloudinary · Vercel + Render.

```
project/
├── frontend/                 static website (no build step)
│   ├── index, articles, topics, about, contact, login, register, submit, dashboard, admin (.html)
│   ├── css/style.css         design system, RTL via logical properties
│   ├── js/                   app.js (API client, auth, layout) + one script per page
│   └── vercel.json           rewrites /api, /uploads, article pages to the backend
├── backend/
│   ├── app/
│   │   ├── main.py, config.py, database.py, models.py, schemas.py, security.py, deps.py, utils.py
│   │   ├── routes/           auth.py · public.py · user.py · admin.py · pages.py (SEO article page, sitemap)
│   │   ├── services/images.py  validation, WebP optimisation, Cloudinary / local storage
│   │   └── templates/article.html   server-rendered article (meta tags, Open Graph)
│   ├── alembic/              migrations
│   ├── scripts/bootstrap.py  seeds categories + settings, creates the first admin
│   └── tests/test_approval.py
└── render.yaml
```

## How it fits together
1. The browser loads static pages and calls `/api/...`. Login returns a short-lived JWT (kept in memory) and a rotating refresh token in an httpOnly cookie.
2. `POST /api/me/articles` stores the submission with `status = 'pending'` (forced by the server) and uploads images through the backend.
3. Admins review in `/admin.html` → **Approve** (`approved`, sets `approved_at`) or **Reject** (`rejected`, with a reason the user sees in their dashboard).
4. Article pages are rendered by FastAPI (`/articles/<category>/<slug>`) so search engines and social networks get real meta tags.

### How "approved only" is enforced
- The public API (`routes/public.py`) and the SEO page only query through `approved_query()` (`status = 'approved'`). There is no public code path that can return pending or rejected rows.
- Database: `CHECK (status IN ('pending','approved','rejected'))`, `CHECK (status <> 'approved' OR approved_at IS NOT NULL)`, partial index on approved rows.
- Admin routes use a `require_admin` dependency that reads the role **from the database** on every request. Registration always creates `role = 'user'`.
- Users can only read/edit/delete their own submissions (ownership is part of the query → other users' items return 404), and cannot edit published articles.
- `tests/test_approval.py` checks all of this end to end.

## Run locally
Requirements: Python 3.11+, PostgreSQL 14+.

```bash
# 1) database
createdb pashto_portal            # or: psql -U postgres -c "CREATE DATABASE pashto_portal;"

# 2) backend
cd backend
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env              # then edit DATABASE_URL and SECRET_KEY

# 3) migrations (first time: create the initial migration from the models)
alembic revision --autogenerate -m "initial schema"
alembic upgrade head

# 4) seed categories/settings + first admin
python -m scripts.bootstrap --email you@example.com --name "Your Name" --password "ChangeMe12345"

# 5) start (serves the API AND the frontend)
uvicorn app.main:app --reload
```
Open http://localhost:8000 · API docs: http://localhost:8000/api/docs

Commit the generated file in `backend/alembic/versions/` — Render runs `alembic upgrade head` on every deploy.

## Environment variables (`backend/.env`)
| Name | Meaning |
|---|---|
| `DATABASE_URL` | PostgreSQL URL (`postgres://` from Render is converted automatically) |
| `SECRET_KEY` | long random string: `python -c "import secrets; print(secrets.token_urlsafe(64))"` |
| `COOKIE_SECURE` | `true` in production (HTTPS) |
| `SITE_URL` | public site URL (sitemap, Open Graph, canonical) |
| `CLOUDINARY_URL` | `cloudinary://API_KEY:API_SECRET@CLOUD_NAME`; empty = store images in `backend/uploads` (dev only) |
| `CORS_ORIGINS` | only if the frontend is on a different origin (not needed with the Vercel rewrites) |
| `ACCESS_TOKEN_MINUTES`, `REFRESH_TOKEN_DAYS`, `MAX_IMAGE_MB` | optional tuning |

## Test the workflow by hand
1. **Register:** `/register.html` → create a normal user.
2. **Submit:** `/submit.html` → fill the form with a main image → you see the success message; the item appears in *Dashboard → Pending*, and is **not** visible on `/articles.html`.
3. **Approve:** log in as the admin → `/admin.html` → *Pending submissions* → **Approve**. The article is now on the homepage and `/articles.html`.
4. **Reject:** submit another → **Reject** with a reason → the user sees it under *Rejected* in the dashboard and in notifications.
5. **Automated:** `pip install -r requirements-dev.txt && pytest -q` (from `backend/`).

## Deploy
**PostgreSQL + backend on Render**
1. Create a PostgreSQL instance (Render or Neon/Supabase free tier). Copy its connection string.
2. New → Web Service from your repo, root directory `backend` (or use `render.yaml`).
   Build: `pip install -r requirements.txt && alembic upgrade head` · Start: `uvicorn app.main:app --host 0.0.0.0 --port $PORT --proxy-headers --forwarded-allow-ips="*"`
3. Set `DATABASE_URL`, `SECRET_KEY`, `COOKIE_SECURE=true`, `SITE_URL=https://your-domain`, `CLOUDINARY_URL`.
4. Create the first admin from the Render shell: `python -m scripts.bootstrap --email ... --password ...`.

**Image storage (Cloudinary):** create a free account → Dashboard → copy the *API environment variable* (`cloudinary://...`) into `CLOUDINARY_URL`. Render's free disk is ephemeral, so never rely on local uploads in production.

**Frontend on Vercel**
1. Edit `frontend/vercel.json`: replace `YOUR-BACKEND.onrender.com` with your Render hostname.
2. Import the repo in Vercel, set *Root Directory* to `frontend`, Framework = *Other* (no build command).
3. Set `SITE_URL` on Render to the Vercel domain. Because Vercel proxies `/api` and article pages to Render, cookies stay first-party and article pages keep their SEO URLs.

(Alternative: deploy only the backend — it already serves the frontend files from the same origin.)

## Notes
- Rich text from admins is sanitised with `bleach` before saving; user submissions are stored as escaped plain text paragraphs.
- Rate limits: login 10/min, registration 10/h, submissions 20/h per IP (in-memory; use Redis storage if you run several instances).
- Search uses `ILIKE`; for large datasets add a `pg_trgm` index or PostgreSQL full-text search.
- Deleting a user deletes their articles and notifications; deleting a category keeps its articles.
- Search engines: `/sitemap.xml` and `/robots.txt` are generated by the backend.
